#include<graphics.h>
#include <conio.h>
#include<iostream>
using namespace std;
  class Fenetres{
public:
     
      void ouvrir_graphique(void);// necessaire avant de commencer le graphique
	  
	  int get_couleur_fond(void);// retourne la couleur du fond 
	  
	  int get_x_max(void);//retourne le x maximal de la fenetre
      
      int get_y_max(void);//retourne le y maximal de la fenetre
      
	  int get_couleur(int x, int y);// retourne la couleur actuelle du point (x,y)
	  
	  void allume(int x, int y ,int c);// allume le point(x,y) dans la couleur c
	  
	  void fermer_graphique(void);// appelle avant quitter le programme
};

